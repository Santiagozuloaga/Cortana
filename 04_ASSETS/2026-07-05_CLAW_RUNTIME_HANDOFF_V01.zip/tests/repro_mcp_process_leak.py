"""
Reproduce: StdioTransport.stop() llama terminate() (SIGTERM) y espera hasta
3s. Si el proceso lo ignora, wait(timeout=3) lanza TimeoutExpired -- que un
`except Exception: pass` genérico traga en silencio. self._process se pone
en None igual, así que el objeto Python "olvida" el proceso, pero el proceso
del sistema operativo sigue vivo -- fuga real de proceso (y de sus 3 pipes).
"""
import sys, os, time, importlib.util, signal

MCP_DIR = "/home/claude/repo/Cortana-master/01_SRC/2024-06-19_CLAW_MCP_V01"
sys.path.insert(0, "/home/claude/repo/Cortana-master/01_SRC")  # para 'mcp' como paquete

import importlib
mcp_pkg = importlib.import_module("mcp")               # via symlink de directorio
mcp_client = importlib.import_module("mcp.client")
mcp_types = importlib.import_module("mcp.types")


def run_test():
    cfg = mcp_types.MCPServerConfig(
        name="stubborn",
        transport=mcp_types.MCPTransport.STDIO,
        command=sys.executable,
        args=["/home/claude/test_ws/stubborn_mcp_server.py"],
        timeout=5,
    )
    t = mcp_client.StdioTransport(cfg)
    t.start()
    pid = t._process.pid
    time.sleep(0.5)  # darle tiempo al hijo a registrar su handler de SIGTERM
    print(f"Servidor 'stubborn' arrancado, PID={pid}, ¿vivo? {t.alive}")

    t0 = time.time()
    t.stop()
    elapsed = time.time() - t0
    print(f"stop() volvió en {elapsed:.1f}s")

    # ¿El proceso del SO sigue vivo, aunque Python ya olvidó la referencia?
    try:
        os.kill(pid, 0)  # no mata; solo chequea si el PID existe
        still_alive = True
    except ProcessLookupError:
        still_alive = False

    print(f"¿El proceso del SO (PID {pid}) sigue vivo tras stop()? {still_alive}")

    # limpieza real para no dejar basura en el sandbox, sin afectar el resultado del test
    if still_alive:
        try:
            os.kill(pid, signal.SIGKILL)
        except Exception:
            pass

    if still_alive:
        print("\nRESULTADO: BUG CONFIRMADO — proceso huérfano, nunca se le mandó SIGKILL.")
        return False
    else:
        print("\nRESULTADO: OK — el proceso terminó correctamente.")
        return True


if __name__ == "__main__":
    ok = run_test()
    sys.exit(0 if ok else 1)
