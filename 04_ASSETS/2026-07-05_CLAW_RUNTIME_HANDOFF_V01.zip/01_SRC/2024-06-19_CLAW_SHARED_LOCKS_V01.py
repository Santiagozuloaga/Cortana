"""Shared process-wide locks used as a TEMPORARY mitigation.

MITIGACIÓN TEMPORAL — no es la arquitectura definitiva.

Contexto: tanto el SubAgent Manager (isolation="worktree", que usa
os.chdir()) como Memory (scope="project", que resuelve su directorio vía
Path.cwd()) dependen del directorio de trabajo del PROCESO, que es estado
global compartido por todos los hilos, no por-hilo.

Bug que esto mitiga (hallazgo del 2026-07-05, auditoría de runtime):
un subagente con isolation="worktree" corriendo en background puede dejar
el proceso con cwd apuntando a su worktree efímero. Si en esa misma ventana
se guarda o borra una memoria de "project", la operación ocurre dentro de
ese worktree — y se pierde en forma permanente cuando el worktree se borra
al terminar la tarea.

Este módulo NO resuelve la causa de fondo (la dependencia de Path.cwd()/
os.getcwd() compartida entre módulos que no se conocen entre sí). Solo
serializa el acceso para que ninguna de las dos partes pise a la otra
mientras esa dependencia siga existiendo.

La eliminación real de esta dependencia (que el directorio de proyecto se
resuelva una sola vez y se pase explícitamente en vez de re-derivarse de
Path.cwd() en cada llamada) queda para una futura versión arquitectónica,
fuera del alcance de esta mitigación.
"""
import threading

worktree_chdir_lock = threading.Lock()
