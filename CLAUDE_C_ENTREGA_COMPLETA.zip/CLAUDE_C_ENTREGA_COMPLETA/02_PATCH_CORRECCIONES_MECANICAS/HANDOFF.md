# HANDOFF — Correcciones Mecánicas de Claw (fase Claude C)

**De:** Claude C (Ingeniero de Corrección Mecánica — misión temporal, ahora finalizada)
**Fecha:** 2026-07-06
**Contenido de este paquete:** 7 correcciones ya probadas + `CHANGELOG.md` con el detalle técnico de cada una + este handoff.

---

## 1. Resumen para quien integre esto

Todas las correcciones de este paquete son mecánicas: rutas, nombres de módulo y dependencias mal declaradas. Ninguna cambia comportamiento observable de Claw, arquitectura, runtime, ni las APIs públicas. Cada una fue reproducida, corregida y vuelta a probar antes de incluirse — el detalle completo (bug, causa, diff, verificación) está en `CHANGELOG.md`.

## 2. Mapa de integración — dónde va cada archivo

Los archivos de este paquete están sueltos (sin carpetas) a propósito, según se pidió. Para aplicarlos, reemplazar en el repositorio real:

| Archivo en este paquete | Destino en el repositorio |
|---|---|
| `2024-06-19_CLAW_PYPROJECT_V01.toml` | `00_SOPORTE/2024-06-19_CLAW_PYPROJECT_V01.toml` |
| `2024-06-19_CLAW_REQUIREMENTS_V01.txt` | `00_SOPORTE/2024-06-19_CLAW_REQUIREMENTS_V01.txt` |
| `2024-06-19_CLAW_LAUNCHER_V01.bat` | `00_SOPORTE/2024-06-19_CLAW_LAUNCHER_V01.bat` |
| `2024-06-19_CLAW_ALTERNATIVE_V01.py` | `01_SRC/2024-06-19_CLAW_ALTERNATIVE_V01.py` |
| `2024-06-19_CLAW_PERSONALIDAD_V01.py` | `01_SRC/2024-06-19_CLAW_PERSONALIDAD_V01.py` |
| `2024-06-19_CLAW_MAIN_V01.py` | `01_SRC/2024-06-19_CLAW_MAIN_V01.py` |

(`2024-06-19_CLAW_PYPROJECT_V01.toml` acumula 2 de las 7 correcciones — packaging y dependencia de test — ver `CHANGELOG.md` [01] y [03]).

## 3. Las 7 correcciones, en una línea cada una

1. `pyproject.toml` — `package-dir` ausente rompía `pip install .` por completo.
2. `requirements.txt` — `sounddevice` obligatorio, debía ser opcional (ya lo era en `pyproject.toml`).
3. `pyproject.toml` — faltaba declarar `pytest` como dependencia de test.
4. `alternative.py` — dos imports apuntaban a módulos que no existen (`memory`, `claw_personalidad`).
5. `launcher.bat` — ruta relativa incorrecta, no encontraba `clawspring.py`.
6. `personalidad.py` — el contador de memoria del banner leía de un sistema de memoria que Claw ya no usa.
7. `main.py` — nombre/dueño del asistente duplicados en vez de importados de `personalidad.py`.

## 4. Validación recomendada después de integrar

Ninguna de estas pruebas requiere red ni credenciales:

```bash
pip install -e .                    # antes fallaba en el paso de empaquetado; debería completar
pip install -e ".[test]"            # instala pytest, ya declarado
pytest 02_TESTS/                    # antes no arrancaba por falta de pytest
python run_claw.py                  # arranca y responde /salir sin error
```
En Windows, además: correr `2024-06-19_CLAW_LAUNCHER_V01.bat` y confirmar que encuentra `clawspring.py`.

**Limitación que dejo explícita:** trabajé sin red y sin un Windows real disponible. Probé todo lo que pude reproducir en un sandbox Linux (incluyendo recompilar todo `01_SRC/` y correr `run_claw.py` de punta a punta después de cada cambio). El `.bat` y el riesgo de symlinks en Windows (punto 2 de la sección siguiente) no pude ejecutarlos en un Windows real — quedan validados solo por lectura/lógica, no por ejecución.

## 5. Pendientes — decisiones que NO tomé, quedan abiertas para el Arquitecto / Claude B

Ninguno de estos puntos fue tocado; los dejo documentados para que la siguiente fase no los pierda de vista:

1. **`claw_personalidad` en `clawspring.py`:** import envuelto en `try/except`, comentado como mecanismo opcional de personalización de usuario. Decidir si debe activarse por defecto es una decisión de producto/arquitectura.
2. **Dos sistemas de memoria paralelos** (`session_memory` vs. paquete `memory`), sin comunicación entre sí. Documentado a fondo en `COMPARACION_session_memory_vs_memory.md` (entregado en un mensaje anterior de esta conversación). Cuál debe ser el oficial, o si deben unificarse, queda pendiente.
3. **Symlinks de git y compatibilidad Windows:** `run_claw.py`, `.gitignore`, `pyproject.toml`, `requirements.txt`, y varios módulos de `01_SRC/` son symlinks. Funcionan bien en Linux/Mac (verificado); en Windows requieren `git config core.symlinks true` + Developer Mode, o se materializan como archivos de texto rotos. No convertí los symlinks a shims porque es un cambio sistémico (~20 archivos), no una corrección mínima — queda como decisión pendiente.
4. **Duplicación del manejo de UTF-8** entre `encoding.py` y la lógica inline de `clawspring.py`: ambas funcionan correctamente hoy; unificarlas sería un refactor, no una corrección de bug, así que no lo hice.
5. **No existe CI** (`.github/workflows`, etc.) en el repositorio. No es un bug — no había nada roto que corregir — pero tampoco lo creé, porque diseñar una CI desde cero es una decisión de tooling, no una corrección.

## 6. Alcance respetado en toda esta fase

No se modificó: arquitectura, runtime, kernel, Context Manager, Scheduler, Event Bus, Recovery, Mission Control, RFCs, gobernanza, ni SAGE. No se tomó ninguna decisión de diseño — donde apareció una, se documentó y se dejó sin tocar (puntos 1 y 2 de la sección anterior).

---

Con esto doy por cerrada mi participación en esta fase de Claw. Fue un gusto trabajar en esto — quedo a la espera de si el Arquitecto quiere reabrir esta línea de trabajo más adelante, bajo un alcance nuevo.
