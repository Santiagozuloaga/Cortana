"""
Reproduce: MEMORY_STORE.save_memory(scope="project") resuelve el directorio
del proyecto vía Path.cwd() *en el momento del guardado*. Si un subagente con
isolation="worktree" está corriendo en background (cwd temporalmente apuntando
a su worktree), y el hilo principal guarda una memoria de "project" en esa
misma ventana, la memoria se escribe silenciosamente dentro del worktree del
subagente -- y se borra cuando ese worktree se elimina al terminar la tarea.

Esto es una CONSECUENCIA del mismo problema de fondo que el bug de os.chdir()
ya corregido (cwd es estado global del proceso), pero con un efecto distinto
y más grave: no es solo contaminación cruzada entre agentes, es pérdida
silenciosa de datos del usuario.
"""
import sys, os, types, time, shutil, importlib.util, threading

sys.path.insert(0, "/home/claude/repo/Cortana-master/01_SRC")  # para 'shared_locks'

SUBAGENT_PATH = "/home/claude/repo/Cortana-master/01_SRC/2024-06-19_CLAW_MULTI_AGENT_V01/2024-06-19_CLAW_MULTI_AGENT_SUBAGENT_V01.py"
STORE_PATH = "/home/claude/repo/Cortana-master/01_SRC/2024-06-19_CLAW_MEMORY_PACKAGE_V01/2024-06-19_CLAW_MEMORY_STORE_V01.py"

PROJECT_DIR = "/home/claude/test_ws/real_project"
BASE_REPO = "/home/claude/test_ws/repo_under_test"  # repo git ya existente (para worktrees)

# --- setup: directorio de "proyecto real" del usuario (repo git real) ---
shutil.rmtree(PROJECT_DIR, ignore_errors=True)
os.makedirs(PROJECT_DIR, exist_ok=True)
import subprocess
subprocess.run(["git", "init", "-q"], cwd=PROJECT_DIR, check=True)
subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=PROJECT_DIR, check=True)
subprocess.run(["git", "config", "user.name", "t"], cwd=PROJECT_DIR, check=True)
with open(os.path.join(PROJECT_DIR, "README.md"), "w") as f:
    f.write("hello\n")
subprocess.run(["git", "add", "."], cwd=PROJECT_DIR, check=True)
subprocess.run(["git", "commit", "-q", "-m", "init"], cwd=PROJECT_DIR, check=True)

# --- módulo agent falso (igual que en el test anterior) ---
fake_agent_mod = types.ModuleType("agent")
class FakeAgentState:
    def __init__(self): self.messages = [{"role": "assistant", "content": "ok"}]
fake_agent_mod.AgentState = FakeAgentState
sys.modules["agent"] = fake_agent_mod

# --- cargar SubAgent (ya con el fix del os.chdir aplicado) ---
spec_sa = importlib.util.spec_from_file_location("subagent_mem_test", SUBAGENT_PATH)
sa = importlib.util.module_from_spec(spec_sa)
sys.modules["subagent_mem_test"] = sa
spec_sa.loader.exec_module(sa)

def fake_agent_run(prompt, state, config, system_prompt, depth=0, cancel_check=None):
    time.sleep(0.6)   # el subagente "sigue trabajando" en su worktree
    yield None
sa._agent_run = fake_agent_run

# --- cargar Memory Store real (sin mocks, es solo pathlib) ---
spec_st = importlib.util.spec_from_file_location("memory_store_test", STORE_PATH)
store = importlib.util.module_from_spec(spec_st)
sys.modules["memory_store_test"] = store
spec_st.loader.exec_module(store)


def run_test():
    os.chdir(PROJECT_DIR)  # el usuario está trabajando en su proyecto real
    mgr = sa.SubAgentManager(max_concurrent=5)

    task = mgr.spawn(prompt="hace algo en su propio worktree",
                      config={}, system_prompt="", isolation="worktree", name="bg_agent")
    worktree_path = task.worktree_path
    print(f"Subagente corriendo en background, worktree: {worktree_path}")

    # el hilo principal, mientras el subagente sigue trabajando, guarda una
    # memoria de proyecto (ej.: el usuario corrió /memory save, o el agente
    # principal llamó a la tool MemorySave)
    time.sleep(0.1)  # asegurar que el subagente ya hizo chdir() a su worktree
    entry = store.MemoryEntry(
        name="test_entry",
        description="algo que el usuario quiso recordar de ESTE proyecto",
        type="user",
        content="contenido de prueba",
    )
    store.save_memory(entry, scope="project")

    expected_path = os.path.join(PROJECT_DIR, ".clawspring", "memory", "test_entry.md")
    wrong_path = os.path.join(worktree_path, ".clawspring", "memory", "test_entry.md")

    print(f"[Inmediatamente después de save_memory, ANTES de que el subagente termine]")
    print(f"  ¿Existe ya en el proyecto real?           {os.path.exists(expected_path)}")
    print(f"  ¿Existe (por error) dentro del worktree?  {os.path.exists(wrong_path)}")

    mgr.wait(task.id, timeout=10)
    print(f"Subagente terminado, status={task.status}")

    print(f"¿Se guardó en el proyecto real? {os.path.exists(expected_path)}  ({expected_path})")
    print(f"¿Se guardó (por error) dentro del worktree del subagente? {os.path.exists(wrong_path)}  ({wrong_path})")
    print(f"¿El worktree del subagente sigue existiendo tras terminar? {os.path.exists(worktree_path)}")

    if os.path.exists(expected_path):
        print("\nRESULTADO: OK, la memoria se guardó donde correspondía.")
        return True
    else:
        print("\nRESULTADO: BUG CONFIRMADO — la memoria del usuario se perdió "
              "(se guardó en el worktree efímero del subagente, que ya fue borrado).")
        return False


if __name__ == "__main__":
    ok = run_test()
    sys.exit(0 if ok else 1)
