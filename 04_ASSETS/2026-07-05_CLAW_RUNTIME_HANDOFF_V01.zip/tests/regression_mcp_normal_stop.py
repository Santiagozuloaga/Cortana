"""
Regresión: confirma que el fix de StdioTransport.stop() (escalar a SIGKILL
solo si SIGTERM no funcionó) no afecta el caso común -- un servidor MCP bien
portado debe seguir cerrándose rápido, sin esperar el timeout de 3s.
"""
import sys, os, time, importlib

sys.path.insert(0, "/home/claude/repo/Cortana-master/01_SRC")
mcp_client = importlib.import_module("mcp.client")
mcp_types = importlib.import_module("mcp.types")


def run_test():
    cfg = mcp_types.MCPServerConfig(
        name="normal", transport=mcp_types.MCPTransport.STDIO,
        command=sys.executable, args=["-c", "import time; time.sleep(60)"], timeout=5,
    )
    t = mcp_client.StdioTransport(cfg)
    t.start()
    pid = t._process.pid
    time.sleep(0.3)

    t0 = time.time()
    t.stop()
    elapsed = time.time() - t0

    try:
        os.kill(pid, 0)
        alive = True
    except ProcessLookupError:
        alive = False

    print(f"Proceso bien portado: stop() tardó {elapsed:.2f}s, ¿sigue vivo? {alive}")

    ok = (elapsed < 1.0) and (not alive)
    if ok:
        print("RESULTADO: OK, sin regresión -- el caso común sigue siendo rápido.")
    else:
        print("RESULTADO: FALLO -- el fix afectó el caso común.")
    return ok


if __name__ == "__main__":
    ok = run_test()
    sys.exit(0 if ok else 1)
