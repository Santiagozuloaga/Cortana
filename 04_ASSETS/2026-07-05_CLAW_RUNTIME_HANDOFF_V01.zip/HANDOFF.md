# HANDOFF — Fase de Ingeniero de Runtime (Claude), cierre de sesión

Fecha: 2026-07-05/06
Rol: Ingeniero de Runtime (distinto del rol anterior de Auditor Documental
— "Claude B" — cuyos hallazgos sobre Constitución/RFC-0040/41/42 quedan
registrados en el chat de esa fase, no se repiten acá).
Estado: fase cerrada por el Arquitecto. Este documento es el traspaso para
quien continúe — otra sesión de Claude, Claude A, Kimi, GLM, Qwen, o quien
corresponda.

---

## 1. Lo más importante para quien empiece de cero acá

**El código real de `01_SRC/` no es SAGE OS.** La arquitectura descrita en
RFC-0040/RFC-0041 (microkernel, Scheduler, Watchdog, Supervisor daemon,
SQLite event store con locks granulares, sandboxing Docker por agente, bus
de eventos, integración n8n/Linear, gVisor/eBPF) **no tiene ninguna huella
de código verificable** en este repositorio. Se buscó explícitamente:
`scheduler`, `watchdog`, `supervisor`, `lock_manager`, `execution.lock`,
`fsm`, `state_machine`, `dead_letter`, `microkernel`, `n8n`, `gVisor`,
`eBPF` — cero coincidencias reales en todo `01_SRC` (las pocas coincidencias
de `docker`/`sqlite`/`linear` que aparecen son falsos positivos: tags de
ejemplo en un motor de recomendación de plugins, vocabulario de un
transcriptor de voz, y un ejemplo en un docstring, respectivamente).

Lo que existe de verdad es **ClawSpring** — así se autodescribe el propio
código: *"Minimal Python implementation of Claude Code"*. Es un asistente
de código por CLI, con estos módulos reales (nombre real ⇄ symlink
limpio ⇄ carpeta):

| Concepto | Symlink / paquete | Archivo real |
|---|---|---|
| Núcleo / bucle principal | `core.py` | `2024-06-19_CLAW_CORE_V01.py` |
| Subagentes | `multi_agent/` | `2024-06-19_CLAW_MULTI_AGENT_V01/` |
| Memoria | `memory/` | `2024-06-19_CLAW_MEMORY_PACKAGE_V01/` |
| MCP | `mcp/` | `2024-06-19_CLAW_MCP_V01/` |
| Plugins | `plugin/` | `2024-06-19_CLAW_PLUGIN_V01/` |
| Proveedores LLM | `providers.py` | `2024-06-19_CLAW_PROVIDERS_V01.py` |

El "Provider Router" real es un conjunto de funciones (`detect_provider`,
`stream_anthropic`, `stream_openai_compat`, `stream_ollama`, etc.), no el
patrón Adapter/Factory con interfaces TypeScript de RFC-0041 §6.

**Herramientas reales usadas en este repo**: hay rastro de Aider
(`.aider.*`) y Cline (`.clinerules`) en la raíz — asistentes de código
reales trabajando sobre este proyecto, no un despliegue autónomo de
Docker/SQLite/microkernel.

No tengo forma de saber si esta brecha entre RFC y código es temporal
(target architecture aún no construida, como dicen los propios RFC) o
permanente (los RFC describen una dirección que se abandonó). No me
corresponde decidirlo — solo dejarlo dicho con toda claridad para que nadie
asuma que "Scheduler" o "Watchdog" existen en runtime porque están en un
RFC.

## 2. Convención de archivos del repo (para quien no la conozca todavía)

Cada módulo real vive en un archivo con fecha (`2024-06-19_CLAW_XXX_V01.py`
o similar). Junto a él hay un **symlink de nombre limpio** (`core.py`,
`store.py`, `memory/`, `mcp/`, etc.) para que los imports de Python
funcionen con nombres normales. Además, algunos módulos tienen un
**`_shim.py`** de compatibilidad hacia atrás (ej. `subagent_shim.py`,
`memory_shim.py`) que re-exporta símbolos para quien todavía importe por
el nombre viejo. Antes de asumir qué archivo es "el real", conviene
verificar la cadena completa (viví esto de cerca: hay al menos dos
archivos, `2024-06-19_CLAW_CLAWSPRING_CORE_V01.py` y
`2024-06-19_CLAW_CLAWSPRING_V02.py`, que son código muerto — nadie los
importa, ver sección 4).

## 3. Bugs corregidos esta sesión

Ver `CHANGELOG.md` para el detalle técnico completo de cada uno
(explicación, archivo, líneas, test, resultado antes/después). Resumen:

| Bug | Severidad | Archivo | Test |
|---|---|---|---|
| Pérdida de memoria de proyecto vía `Path.cwd()` | Crítico | `MEMORY_STORE` | `test_memory_project_scope_loss.py` |
| Mismo patrón en instalación de plugins | Crítico | `PLUGIN_STORE` | `test_plugin_project_scope_loss.py` |
| Race de `os.chdir()` entre subagentes worktree | Alto | `MULTI_AGENT_SUBAGENT` | `test_worktree_race.py` |
| Fuga de proceso MCP (sin escalar a SIGKILL) | Medio | `MCP_CLIENT` | `repro_mcp_process_leak.py` + `regression_mcp_normal_stop.py` |
| `except:` desnudo en generador de identidades | Bajo | `CORE_V01.py` | — (verificado por inspección) |

Todos los tests están en `tests/` y pasan contra los archivos de
`01_SRC/` incluidos en este paquete. Requieren solo Python 3.12+ y `git`
en PATH — no requieren claves de API ni red: el módulo `agent` (el que
haría las llamadas reales al modelo) se reemplaza por un stub en cada
test, a propósito, para aislar los bugs de concurrencia/integridad de
datos del comportamiento real del LLM.

## 4. Deuda técnica pendiente — decisiones de arquitectura NO implementadas

Esto es explícitamente lo que el Arquitecto pidió dejar documentado sin
tocar. Ninguno de estos puntos fue implementado.

### 4.1 Causa de fondo de la familia de bugs de `Path.cwd()`
La mitigación aplicada (`shared_locks.py` / `worktree_chdir_lock`) es un
parche de coordinación, no una solución de fondo. La causa real: el
directorio de "proyecto" se re-deriva de `Path.cwd()` en cada llamada, en
vez de resolverse una sola vez y pasarse explícitamente. Mientras eso siga
así, cualquier código nuevo que dependa de `Path.cwd()` para scope de
proyecto puede reintroducir esta clase de bug sin que el lock lo cubra
automáticamente (el lock protege lo que yo encontré y envolví a mano —
`Memory` y `Plugin` — no es una propiedad estructural del sistema).

**Importante — esto no fue una búsqueda exhaustiva.** Encontré estas tres
instancias (`SubAgent`, `Memory`, `Plugin`) investigando hallazgos
puntuales, no barriendo todo el repo en busca de cada uso de `Path.cwd()`
u `os.getcwd()`. Es razonable esperar que existan más lugares con el mismo
patrón (Session/CloudSave, Task, Voice no se revisaron con este lente
específico).

La solución de fondo — resolver el root del proyecto una vez y pasarlo
explícitamente en vez de re-derivarlo — es, con toda propiedad, un cambio
de arquitectura. Queda para una próxima versión, no para esta sesión.

### 4.2 Race condition angosta en `query_lock` / Telegram (CORE_V01.py)
Dentro de `_tg_poll_loop`, dos lecturas de `state.messages` ocurren después
de liberado `query_lock`; si la REPL dispara una consulta nueva en esa
ventana exacta, esa lectura queda sin protección. **Deprioritizado
explícitamente por el Arquitecto** (el foco actual es WhatsApp, no
Telegram) — señalado, sin reproducir, sin test, sin corregir.

### 4.3 Código muerto: `CLAWSPRING_CORE_V01.py` y `CLAWSPRING_V02.py`
Dos archivos de ~3370-3413 líneas, casi idénticos a `CORE_V01.py` (el que
sí se ejecuta — confirmado rastreando el entrypoint real, `RUN_V01.py` →
`import_module("2024-06-19_CLAW_CORE_V01")`). Ninguno de los dos se
importa desde ningún lado. No se tocaron ni se borraron — decisión de
limpieza, no de bug-fixing, fuera del alcance de esta sesión.

### 4.4 Provider Router
Solo revisión estructural (mapeo de funciones, sin hallazgos de este
calibre). **Congelado por instrucción explícita** del Arquitecto para no
interferir con la integración en curso de las ramas de Claude A, Kimi, GLM
y Qwen. No profundizar sin nueva autorización.

## 5. Cómo aplicar este paquete
Los archivos bajo `01_SRC/` en este .zip tienen exactamente la misma ruta
relativa que en el repositorio real — se pueden copiar encima directamente.
Todos verificados con `ast.parse` (sintaxis válida) antes de empaquetar.

---
Fin de la participación de esta sesión en la fase de Runtime Engineer de
CLAW. Cierre a la espera de nueva asignación.
