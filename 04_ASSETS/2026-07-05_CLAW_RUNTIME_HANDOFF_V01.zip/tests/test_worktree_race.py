"""
Reproduce: SubAgentManager usa os.chdir() (estado GLOBAL del proceso) dentro de
tareas ejecutadas en un ThreadPoolExecutor (max_concurrent, por defecto 5).
Si 2+ subagentes con isolation="worktree" corren al mismo tiempo, sus llamadas
a os.chdir() se pisan entre sí.

Este script:
 1. Inyecta un módulo 'agent' falso (para no depender de API keys reales).
 2. Reemplaza _agent_run por una función falsa que solo observa os.getcwd()
    al inicio y a mitad de su "trabajo" (con una pausa en el medio para dar
    tiempo a que el otro hilo interfiera).
 3. Lanza 2 subagentes con isolation="worktree" casi al mismo tiempo.
 4. Verifica que cada tarea vio el MISMO cwd al inicio y a la mitad de su
    propia ejecución. Si no, hubo interferencia cruzada = bug confirmado.
"""
import sys, os, types, time, importlib.util, threading

sys.path.insert(0, "/home/claude/repo/Cortana-master/01_SRC")  # para 'shared_locks'

REPO = "/home/claude/test_ws/repo_under_test"
MODULE_PATH = "/home/claude/repo/Cortana-master/01_SRC/2024-06-19_CLAW_MULTI_AGENT_V01/2024-06-19_CLAW_MULTI_AGENT_SUBAGENT_V01.py"

# 1. Módulo 'agent' falso, para satisfacer `import agent as _agent_mod` dentro de _run()
fake_agent_mod = types.ModuleType("agent")
class FakeAgentState:
    def __init__(self):
        self.messages = [{"role": "assistant", "content": "ok"}]
fake_agent_mod.AgentState = FakeAgentState
sys.modules["agent"] = fake_agent_mod

# Cargar el módulo real bajo prueba desde su ruta (nombre de archivo no es
# un identificador Python válido, así que se carga por ruta explícita)
spec = importlib.util.spec_from_file_location("subagent_under_test", MODULE_PATH)
sa = importlib.util.module_from_spec(spec)
sys.modules["subagent_under_test"] = sa   # necesario para que @dataclass resuelva el módulo
spec.loader.exec_module(sa)

observations = {}   # label -> (start_cwd, mid_cwd)
lock_for_dict = threading.Lock()

def fake_agent_run(prompt, state, config, system_prompt, depth=0, cancel_check=None):
    label = config["_label"]
    start_cwd = os.getcwd()
    time.sleep(0.4)          # ventana amplia para que el otro hilo interfiera
    mid_cwd = os.getcwd()
    with lock_for_dict:
        observations[label] = (start_cwd, mid_cwd)
    yield None

# 2. Reemplazar la función real por la falsa en el módulo bajo prueba
sa._agent_run = fake_agent_run

def run_test():
    os.chdir(REPO)
    mgr = sa.SubAgentManager(max_concurrent=5)

    cfg_a = {"_label": "A"}
    cfg_b = {"_label": "B"}

    task_a = mgr.spawn(prompt="a", config=cfg_a, system_prompt="", isolation="worktree", name="agentA")
    task_b = mgr.spawn(prompt="b", config=cfg_b, system_prompt="", isolation="worktree", name="agentB")

    print(f"worktree A: {task_a.worktree_path}")
    print(f"worktree B: {task_b.worktree_path}")

    mgr.wait(task_a.id, timeout=10)
    mgr.wait(task_b.id, timeout=10)

    print(f"Task A status: {task_a.status}  result: {task_a.result}")
    print(f"Task B status: {task_b.status}  result: {task_b.result}")
    print(f"Observado A (start, mid): {observations.get('A')}")
    print(f"Observado B (start, mid): {observations.get('B')}")

    ok = True
    for label in ("A", "B"):
        if label not in observations:
            print(f"[FALLO] tarea {label} nunca corrió _agent_run")
            ok = False
            continue
        start, mid = observations[label]
        if start != mid:
            print(f"[RACE DETECTADA] tarea {label}: cwd al inicio ({start}) != cwd a mitad de camino ({mid})."
                  f" Otro hilo cambió el directorio de todo el proceso mientras esta tarea corría.")
            ok = False
    if ok:
        print("\nRESULTADO: sin interferencia detectada (cwd estable en ambas tareas).")
    else:
        print("\nRESULTADO: BUG CONFIRMADO — os.chdir() de una tarea afectó a la otra.")
    return ok

if __name__ == "__main__":
    result = run_test()
    sys.exit(0 if result else 1)
