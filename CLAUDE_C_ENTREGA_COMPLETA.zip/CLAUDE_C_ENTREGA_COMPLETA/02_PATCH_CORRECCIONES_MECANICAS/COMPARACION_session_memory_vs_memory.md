# Comparación: `session_memory` vs. `memory` — dos sistemas de historial/memoria paralelos

**Autor:** Claude C
**Fecha:** 2026-07-05
**Propósito:** documentar, sin tomar partido, las diferencias entre los dos sistemas de memoria que conviven hoy en el repositorio, como base para que el Arquitecto decida cuál será el sistema oficial en una futura migración. No incluye recomendación de cuál elegir — es un levantamiento de hechos.

---

## 1. Resumen de una línea

| | `session_memory` | `memory` (paquete) |
|---|---|---|
| **Qué guarda** | Transcripciones completas de sesiones (mensajes usuario/asistente) | Hechos/preferencias puntuales, curados, uno por archivo |
| **Formato** | JSON | Markdown (`.md`) con frontmatter |
| **Ruta** | `~/.claw/memoria/*.json` | `~/.clawspring/memory/*.md` (o `.clawspring/memory/` del proyecto) |
| **Quién lo usa hoy** | `main.py`, `alternative.py` | `clawspring.py` (entry point real, vía `run_claw.py`) |
| **Búsqueda** | No tiene | Sí (`search_memory`) |
| **Expuesto como tool al LLM** | No | Sí (`_memory_save`, `_memory_search`, `_memory_delete`, `_memory_list`) |
| **Consolidación por IA** | No | Sí (`consolidate_session`) |

---

## 2. Quién usa cada uno

**`session_memory`:**
- `01_SRC/2024-06-19_CLAW_MAIN_V01.py` (`main.py`) — importa `guardar_memoria_auto`, `cargar_sesion`.
- `01_SRC/2024-06-19_CLAW_ALTERNATIVE_V01.py` (`alternative.py`) — mismo uso (corregido en el parche anterior; antes apuntaba al módulo equivocado).

**`memory`:**
- `01_SRC/2024-06-19_CLAW_CLAWSPRING_V02.py` (`clawspring.py`, el entry point que arranca `run_claw.py`) — usa `search_memory`, `load_index`, `consolidate_session` para el comando `/memory`.
- `01_SRC/2024-06-19_CLAW_PERSONALIDAD_V01.py` (`personalidad.py`) — desde el parche anterior, `contar_sesiones()` también lo usa (`scan_all_memories`), para que el conteo del banner coincida con lo que ve `/memory`.

**No hay ningún punto del código donde ambos sistemas se comuniquen o compartan datos.** Son dos silos independientes.

---

## 3. Formato de almacenamiento

### `session_memory`
Un archivo JSON por sesión, nombrado `{session_id}.json`:
```json
{
  "session_id": "...",
  "guardado_en": "2026-07-05T10:00:00",
  "mensajes": [ /* lista completa de mensajes usuario/asistente */ ],
  "metadata": { /* libre */ }
}
```
- Escritura atómica (archivo `.tmp` + rename).
- Antes de guardar, filtra "thinking blocks" de los mensajes del asistente (ver §5, Bug #12).
- No tiene índice separado; para listar sesiones, recorre todos los `.json` del directorio.

### `memory`
Un archivo Markdown por entrada, nombrado `{slug-del-nombre}.md`, más un índice `MEMORY.md` autogenerado. Cada entrada es un objeto `MemoryEntry` con campos: `name`, `description`, `type` (`user`/`feedback`/`project`/`reference`), `content`, `created`, `scope` (`user`/`project`), `confidence` (0.0–1.0), `source` (`user`/`model`/`tool`/`consolidator`), `last_used_at`, `conflict_group`.
- No guarda transcripciones completas — guarda hechos/preferencias individuales y curados.
- Tiene dos ámbitos (`scope`): `user` (global) y `project` (por proyecto).

---

## 4. Rutas de almacenamiento

| Sistema | Ámbito | Ruta |
|---|---|---|
| `session_memory` | único (no distingue ámbito) | `~/.claw/memoria/` |
| `memory` | user | `~/.clawspring/memory/` |
| `memory` | project | `.clawspring/memory/` (relativo al directorio de trabajo) |

Nombres de carpeta base distintos (`.claw` vs. `.clawspring`) — coincide con la misma dualidad de nombre que aparece en el resto del proyecto (CLAW vs. ClawSpring).

---

## 5. Origen / motivación de cada uno (según el propio código)

**`session_memory`:** su docstring dice literalmente *"memory.py — Correcciones Bug #6 y #12: Memoria automática segura"*. Fue escrito como parche puntual para dos bugs específicos:
- **Bug #6:** el guardado original era "fire-and-forget" sin manejo de errores.
- **Bug #12:** los "thinking blocks" guardados en una sesión rompían la API al reproducirse (error 400) en una sesión nueva o con otro modelo.

Es decir: nació como corrección de un mecanismo de guardado de sesión más antiguo (no incluido en lo que revisé), no como un sistema de memoria diseñado desde cero.

**`memory`:** no tiene ese tono de "parche"; está organizado como un paquete completo con tipos (`types.py`), almacenamiento (`store.py`), escaneo (`scan.py`), consolidación (`consolidator.py`) y herramientas expuestas al LLM (`tools.py`) — con docstrings orientados a diseño de API, no a corrección de bugs puntuales.

---

## 6. Ventajas relativas (hechos observables, no opinión)

**`session_memory`:**
- Más simple (un archivo, sin dependencias entre módulos).
- Guarda la conversación completa, útil para retomar una sesión exacta donde quedó (`cargar_sesion` devuelve los mensajes tal cual).
- Ya tiene manejo explícito de errores de disco/permisos con logging.

**`memory`:**
- Tiene búsqueda (`search_memory`) — `session_memory` no.
- Distingue memoria de usuario vs. de proyecto — `session_memory` no distingue ámbitos.
- Se integra como herramienta que el propio modelo puede invocar (guardar/buscar/borrar durante la conversación) — `session_memory` es únicamente guardado/carga automática por el programa, no algo que el modelo decida usar.
- Tiene consolidación asistida por IA (extraer hechos duraderos de una sesión) — `session_memory` guarda la sesión cruda, sin resumir/curar.
- Guarda entradas individuales legibles en Markdown (más fácil de inspeccionar o editar a mano) en vez de blobs JSON de conversación completa.

---

## 7. Dependencias

**`session_memory`:** solo librería estándar (`asyncio`, `json`, `logging`, `os`, `pathlib`, `datetime`, `typing`). Sin dependencias entre sí y otros módulos del proyecto (no importa `memory`, ni viceversa).

**`memory`:** paquete de varios módulos internos que dependen entre sí (`store.py`, `scan.py`, `types.py`, `context.py`, `consolidator.py`, `tools.py`, más `__init__.py` re-exportando todo). `consolidator.py` (`consolidate_session`) no importa un cliente de IA directamente en el nivel superior del archivo — no confirmé si la llamada al modelo ocurre más adentro de la función o si recibe el resultado ya generado desde quien la invoca; lo dejo señalado como algo a verificar si es relevante para la decisión de migración, no lo afirmo como hecho.

---

## 8. Lo que este documento NO decide

No recomiendo cuál sistema debería ser "el oficial". Ambos resuelven necesidades algo distintas (transcripción completa vs. memoria curada/buscable), por lo que la decisión probablemente no sea un simple "elegir uno" sino definir si deben fusionarse, coexistir con roles distintos, o si uno debe reemplazar al otro. Esa definición es una decisión de arquitectura del Arquitecto, no mía.
