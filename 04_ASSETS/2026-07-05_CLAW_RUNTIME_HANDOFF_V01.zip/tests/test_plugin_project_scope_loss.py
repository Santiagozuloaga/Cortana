"""
Reproduce (correctamente, con concurrencia real): install_plugin(scope=PROJECT)
depende de Path.cwd(). Un subagente real con isolation="worktree" corre en
background (via SubAgentManager, el mismo mecanismo ya usado en
test_memory_project_scope_loss.py); mientras sigue "trabajando" (cwd apuntando
a su worktree), el hilo principal instala un plugin de proyecto.

Nota: una versión anterior de este test cambiaba cwd de forma secuencial en
un solo hilo antes de llamar a install_plugin. Eso no prueba nada sobre el
lock -- sin una segunda cosa compitiendo *al mismo tiempo*, no hay condición
de carrera que un mutex pueda evitar. Esta versión corrige eso usando el
mismo subagente real (ThreadPoolExecutor) que expuso el bug original.
"""
import sys, os, types, time, shutil, importlib.util, importlib

sys.path.insert(0, "/home/claude/repo/Cortana-master/01_SRC")

SUBAGENT_PATH = "/home/claude/repo/Cortana-master/01_SRC/2024-06-19_CLAW_MULTI_AGENT_V01/2024-06-19_CLAW_MULTI_AGENT_SUBAGENT_V01.py"

REAL_PROJECT = "/home/claude/test_ws/plugin_real_project2"
LOCAL_PLUGIN_SRC = "/home/claude/test_ws/local_plugin_src2"


def setup():
    for d in (REAL_PROJECT, LOCAL_PLUGIN_SRC):
        shutil.rmtree(d, ignore_errors=True)
        os.makedirs(d, exist_ok=True)
    with open(os.path.join(LOCAL_PLUGIN_SRC, "tool.py"), "w") as f:
        f.write("# plugin de prueba\n")
    import subprocess
    subprocess.run(["git", "init", "-q"], cwd=REAL_PROJECT, check=True)
    subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=REAL_PROJECT, check=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=REAL_PROJECT, check=True)
    with open(os.path.join(REAL_PROJECT, "README.md"), "w") as f:
        f.write("hello\n")
    subprocess.run(["git", "add", "."], cwd=REAL_PROJECT, check=True)
    subprocess.run(["git", "commit", "-q", "-m", "init"], cwd=REAL_PROJECT, check=True)


# --- módulo agent falso (igual que en tests anteriores) ---
fake_agent_mod = types.ModuleType("agent")
class FakeAgentState:
    def __init__(self): self.messages = [{"role": "assistant", "content": "ok"}]
fake_agent_mod.AgentState = FakeAgentState
sys.modules["agent"] = fake_agent_mod

spec_sa = importlib.util.spec_from_file_location("subagent_plugin_test", SUBAGENT_PATH)
sa = importlib.util.module_from_spec(spec_sa)
sys.modules["subagent_plugin_test"] = sa
spec_sa.loader.exec_module(sa)

def fake_agent_run(prompt, state, config, system_prompt, depth=0, cancel_check=None):
    time.sleep(0.6)   # el subagente "sigue trabajando" en su worktree
    yield None
sa._agent_run = fake_agent_run

plugin_store = importlib.import_module("plugin.store")
plugin_types = importlib.import_module("plugin.types")


def run_test():
    setup()
    os.chdir(REAL_PROJECT)  # el usuario está trabajando en su proyecto real
    mgr = sa.SubAgentManager(max_concurrent=5)

    task = mgr.spawn(prompt="hace algo en su propio worktree",
                      config={}, system_prompt="", isolation="worktree", name="bg_agent")
    print(f"Subagente corriendo en background, worktree: {task.worktree_path}")

    time.sleep(0.1)  # asegurar que el subagente ya hizo chdir() a su worktree

    ok, msg = plugin_store.install_plugin(
        f"myplugin@{LOCAL_PLUGIN_SRC}",
        scope=plugin_types.PluginScope.PROJECT,
    )
    print(f"install_plugin() -> ok={ok}, msg={msg}")

    mgr.wait(task.id, timeout=10)
    print(f"Subagente terminado, status={task.status}")

    expected = os.path.join(REAL_PROJECT, ".clawspring", "plugins", "myplugin")
    print(f"¿Se instaló en el proyecto real?  {os.path.exists(expected)}  ({expected})")

    if os.path.exists(expected):
        print("\nRESULTADO: OK, se instaló donde correspondía.")
        return True
    else:
        print("\nRESULTADO: BUG CONFIRMADO — el plugin se perdió (se instaló en el "
              "worktree efímero del subagente, ya borrado).")
        return False


if __name__ == "__main__":
    ok = run_test()
    sys.exit(0 if ok else 1)
