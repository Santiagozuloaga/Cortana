# CHANGELOG — Runtime Engineer, sesión 2026-07-05/06

Alcance de esta sesión: CORE_V01.py, Provider Router, SubAgent Manager,
Memory Engine, MCP, Plugin System. Metodología en todos los casos:
reproducir con test real → confirmar → corrección mínima → volver a
correr el mismo test → documentar. Sin cambios de arquitectura, sin
refactors, sin features nuevas.

## Fixed

### [CRÍTICO] Pérdida silenciosa de datos de usuario — Memory
`save_memory()` / `delete_memory()` con `scope="project"` resuelven el
directorio vía `Path.cwd()` (estado global del proceso). Un subagente con
`isolation="worktree"` corriendo en background puede dejar el proceso con
`cwd` apuntando a su worktree efímero; guardar o borrar una memoria de
proyecto en esa ventana la escribe dentro del worktree — y se pierde para
siempre cuando el worktree se borra al terminar la tarea.
- Archivo: `01_SRC/2024-06-19_CLAW_MEMORY_PACKAGE_V01/2024-06-19_CLAW_MEMORY_STORE_V01.py`
- Test: `tests/test_memory_project_scope_loss.py`
- Antes del fix: falla (memoria perdida). Después: pasa.

### [CRÍTICO] Mismo patrón — Plugin System
`install_plugin()`, `_save_entry()`, `_remove_entry()` con `scope=PROJECT`
tienen la misma dependencia de `Path.cwd()` que Memory. Mismo disparador,
mismo riesgo de pérdida (plugin instalado y luego destruido junto con el
worktree del subagente).
- Archivo: `01_SRC/2024-06-19_CLAW_PLUGIN_V01/2024-06-19_CLAW_PLUGIN_STORE_V01.py`
- Test: `tests/test_plugin_project_scope_loss.py`
- Antes del fix: falla. Después: pasa. (Nota de proceso: la primera versión
  de este test estaba mal planteada — cambiaba `cwd` de forma secuencial en
  un solo hilo, sin concurrencia real, así que "confirmaba" el bug incluso
  contra el código ya corregido. Se detectó porque el resultado no tenía
  sentido, y se rehizo con un subagente real en background antes de dar el
  fix por válido. La versión con la metodología correcta es la que queda
  en este paquete.)

### [ALTO] Race condition entre subagentes con `isolation="worktree"`
`SubAgentManager` corre subagentes en un `ThreadPoolExecutor`;
`isolation="worktree"` usaba `os.chdir()` — estado global del proceso, no
por hilo — para entrar/salir del worktree aislado. Dos o más subagentes
worktree-isolados corriendo a la vez se pisaban el directorio de trabajo
entre sí, sin ningún error visible.
- Archivo: `01_SRC/2024-06-19_CLAW_MULTI_AGENT_V01/2024-06-19_CLAW_MULTI_AGENT_SUBAGENT_V01.py`
- Test: `tests/test_worktree_race.py`
- Antes: cwd observado a mitad de tarea no coincide con el cwd de inicio en
  ninguna de las dos tareas concurrentes. Después: coincide en ambas.
- Confirmado sin regresión: tareas SIN `isolation="worktree"` siguen
  corriendo en paralelo real (no se serializan).

### [MEDIO] Fuga de proceso en MCP stdio
`StdioTransport.stop()` no escalaba a SIGKILL si el servidor MCP ignoraba
SIGTERM dentro del timeout de 3s. El `TimeoutExpired` se tragaba en
silencio (`except Exception: pass`) y el proceso quedaba huérfano, vivo,
con sus 3 pipes abiertos.
- Archivo: `01_SRC/2024-06-19_CLAW_MCP_V01/2024-06-19_CLAW_MCP_CLIENT_V01.py`
- Tests: `tests/repro_mcp_process_leak.py`, `tests/regression_mcp_normal_stop.py`
  (usa el helper `tests/stubborn_mcp_server.py`, un proceso que ignora
  SIGTERM a propósito)
- Antes: proceso confirmado vivo tras `stop()` (`os.kill(pid, 0)` no lanza
  excepción). Después: proceso confirmado muerto. Sin regresión: un
  servidor bien portado sigue cerrando en ~0s, no en 3s.

### [BAJO] `except:` desnudo en CORE
En el generador de identidades del modo brainstorm, un `except:` desnudo
tragaba también `KeyboardInterrupt`/`SystemExit`, no solo el `ImportError`
esperado si falta la librería `faker`.
- Archivo: `01_SRC/2024-06-19_CLAW_CORE_V01.py` (línea ~562)
- Verificado por inspección + chequeo de sintaxis (`ast.parse`). Sin test
  dedicado: cambio de una línea, sin comportamiento concurrente ni de
  estado que reproducir.

## Added
- `01_SRC/2024-06-19_CLAW_SHARED_LOCKS_V01.py` (+ symlink `shared_locks.py`,
  mismo patrón que el resto del proyecto): lock compartido
  (`worktree_chdir_lock`) entre SubAgent Manager y los módulos que dependen
  de `Path.cwd()` para su scope de proyecto (Memory, Plugin System).
  **Mitigación temporal, no arquitectura definitiva** — ver HANDOFF.md,
  sección "Deuda técnica pendiente".

## Evaluado sin cambios
- **Provider Router**: revisión estructural únicamente. Sin hallazgos de
  este calibre. Congelado por instrucción explícita — no profundizar
  mientras se integran las ramas de Claude A, Kimi, GLM y Qwen.
- **HttpTransport (MCP)**, **MCPManager**: revisados, sin hallazgos.
- **CORE_V01.py**: revisado en profundidad (spinner de herramientas,
  hilo de Telegram, `query_lock`). Un hallazgo menor quedó señalado sin
  corregir — ver HANDOFF.md.
