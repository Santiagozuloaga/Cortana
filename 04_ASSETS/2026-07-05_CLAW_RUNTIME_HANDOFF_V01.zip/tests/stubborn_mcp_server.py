import signal
import sys
import time

# Ignora SIGTERM a propósito -- simula un servidor MCP que no responde
# al cierre elegante (colgado, en un bucle, o simplemente mal escrito).
signal.signal(signal.SIGTERM, signal.SIG_IGN)

sys.stdout.write("")  # nada que decir, solo sobrevive
sys.stdout.flush()
while True:
    time.sleep(0.1)
