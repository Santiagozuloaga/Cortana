# CHANGELOG — PATCH_CLAUDE_C_01

**Estado: CERRADO — entrega final de la fase de Claude C (7/7 correcciones, aprobadas).**

Parche generado por Claude C (fase: Ingeniero de Corrección Mecánica).
Contiene únicamente correcciones ya demostradas, mínimas, sin cambios de arquitectura ni de API pública.
Changelog incremental — cada entrada se agrega, no reemplaza a las anteriores.

---

## [01] `2024-06-19_CLAW_PYPROJECT_V01.toml` (`00_SOPORTE/`) — packaging roto

**Problema:** `pip install .` / `pip install -e .` fallaba siempre.
**Causa:** faltaba `package-dir` en `[tool.setuptools]`; `setuptools` buscaba `packages`/`py-modules` en la raíz en vez de en `01_SRC/`. Dos nombres (`skills`, `subagent`) tampoco coincidían con los archivos reales (`skills_shim.py`, `subagent_shim.py`).

```diff
 [tool.setuptools]
+package-dir = {"" = "01_SRC"}
 py-modules = [
     ...
-    "skills",
-    "subagent",
+    "skills_shim",
+    "subagent_shim",
```

**Verificación:** `build_meta.prepare_metadata_for_build_wheel()` — antes: `SystemExit: error: package directory 'mcp' does not exist`; después: build limpio.
**Seguridad:** solo config de build; la instalación ya estaba 100% rota, no hay comportamiento previo que romper. Confirmé que nada importa `skills`/`subagent` (sin `_shim`) como nombre instalado.

---

## [02] `2024-06-19_CLAW_REQUIREMENTS_V01.txt` (`00_SOPORTE/`) — dependencia opcional instalada como obligatoria

**Problema:** `pip install -r requirements.txt` instalaba `sounddevice` para todos, aunque `pyproject.toml` lo declara opcional (`[voice]`).
**Causa:** línea suelta sin comentar, contradiciendo el propio bloque de comentarios del archivo que ya lo documenta como opcional.

```diff
-sounddevice
+# sounddevice  # optional: install via `pip install .[voice]` (see below)
```

**Verificación:** confirmé que ninguna línea activa del archivo menciona ya `sounddevice`; solo quedan las 4 dependencias base, iguales a `pyproject.toml`.
**Seguridad:** revisé el único uso real (`2024-06-19_CLAW_VOICE_RECORDER_V01.py`) — el import ya está protegido con `try/except` y fallback a otros backends. Sin regresión.

---

## [03] `2024-06-19_CLAW_PYPROJECT_V01.toml` (`00_SOPORTE/`) — dependencia de test ausente

**Problema:** `pytest 02_TESTS/` fallaba con `ModuleNotFoundError: No module named 'pytest'` incluso tras instalar el proyecto como está documentado.
**Causa:** 18 de 21 archivos de test hacen `import pytest`; no está declarado ni en `requirements.txt` ni en `pyproject.toml`.

```diff
 [project.optional-dependencies]
 voice  = ["sounddevice"]
 vision = ["Pillow"]
+test   = ["pytest"]
```

**Verificación:** rebuild de metadatos -> `Provides-Extra: test`, `Requires-Dist: pytest ; extra == 'test'`. Sin errores.
**Seguridad:** solo agrega una entrada a una lista existente; no toca código.

---

## [04] `2024-06-19_CLAW_ALTERNATIVE_V01.py` (`01_SRC/`) — imports rotos

**Problema:** importar/ejecutar el archivo fallaba con `ImportError: cannot import name 'guardar_memoria_auto' from 'memory'`.
**Causa:** las funciones existen, con firmas compatibles, pero en el módulo `session_memory`, no en `memory`. El import de `claw_personalidad` en la línea siguiente también apuntaba mal: el módulo real es `personalidad` (confirmé que las 6 funciones/constantes importadas existen ahí).

```diff
-from memory     import guardar_memoria_auto, cargar_sesion, listar_sesiones
+from session_memory import guardar_memoria_auto, cargar_sesion, listar_sesiones
 ...
-from claw_personalidad import (
+from personalidad import (
```

**Verificación:** reimporté el archivo completo -> antes fallaba, ahora `IMPORT OK`. Recompilé todo `01_SRC/` de nuevo -> limpio.
**Seguridad:** verifiqué firmas antes de tocar nada; `main.py` ya usa `session_memory` correctamente, confirmando que es el nombre correcto. Ningún otro archivo depende de los nombres viejos.

---

## [05] `2024-06-19_CLAW_LAUNCHER_V01.bat` (`00_SOPORTE/`) — ruta incorrecta, el lanzador de Windows no arranca nada

**Problema:** hacer doble clic en el lanzador de Windows no inicia la aplicación.
**Causa:** el script hace `cd /d "%~dp0"` (queda en `00_SOPORTE/`) y luego ejecuta `python clawspring.py` — pero ese archivo solo existe en `01_SRC/`, no en `00_SOPORTE/`. Confirmé que no hay ninguna otra copia del `.bat` en el repositorio.

```diff
 REM Iniciar ClawSpring
-python clawspring.py --model ollama/qwen3.5:latest %*
+python ..\01_SRC\clawspring.py --model ollama/qwen3.5:latest %*
```

**Verificación:** no hay Windows disponible en este entorno para correr el `.bat` directamente; verifiqué la resolución de la ruta relativa (`00_SOPORTE/../01_SRC/clawspring.py` apunta al archivo real). El resto del script no se modificó.
**Seguridad:** un solo cambio de ruta; no hay otro archivo que invoque este `.bat` esperando el comportamiento roto.

---

## [06] `2024-06-19_CLAW_PERSONALIDAD_V01.py` (`01_SRC/`) — el contador de memoria del banner no coincide con `/memory`

**Problema:** el banner de arranque muestra "N sesión(es) en memoria", sin relación con lo que el comando `/memory` realmente contiene.
**Causa:** `contar_sesiones()` contaba archivos `.json` en `~/.claw/memoria/memoria/` (sistema `session_memory.py`, que `clawspring.py` no usa). El entry point real usa el paquete `memory` (`.md` en `~/.clawspring/memory/`) para `/memory`. Son dos sistemas de memoria paralelos y desconectados.

```diff
 def contar_sesiones() -> int:
-    """Retorna el número de sesiones guardadas en ~/.claw/memoria/"""
-    mem_dir = MEMORIA_DIR / "memoria"
-    if not mem_dir.exists():
-        return 0
-    return len(list(mem_dir.glob("*.json")))
+    """Retorna el número de memorias guardadas (mismo origen que usa /memory)."""
+    from memory import scan_all_memories
+    return len(scan_all_memories())
```

**Verificación:** `contar_sesiones()` ejecuta y devuelve `int` correctamente; recompilé todo `01_SRC/` (limpio); corrí `python run_claw.py` de punta a punta (arranca y cierra sin error).
**Seguridad:** reutiliza una función ya existente y en uso (`memory.scan_all_memories`) en vez de nueva lógica de rutas; no cambia la firma de `contar_sesiones()`; sin import circular (verificado).

---

## [07] `2024-06-19_CLAW_MAIN_V01.py` (`01_SRC/`) — identidad del asistente duplicada en dos fuentes

**Problema:** `main.py` mantenía su propia copia hardcodeada del nombre del asistente y del dueño ("Claw", "Santiago"), independiente de `personalidad.py` (la fuente que sí usan `alternative.py` y el resto). Hoy coinciden en valor, pero son dos fuentes de verdad separadas — si una cambia, la otra queda desactualizada en silencio.
**Causa:** `main.py` nunca importó estas constantes de `personalidad.py`; las definió aparte.

```diff
-NOMBRE_CLAW = "Claw"
+from personalidad import NOMBRE as NOMBRE_CLAW, DUEÑO
 TONO_CLAW = "directo, técnico y amigable"
-CONTEXTO_CLAW = """Eres Claw, un asistente de IA local desarrollado por Santiago.
+CONTEXTO_CLAW = f"""Eres Claw, un asistente de IA local desarrollado por {DUEÑO}.
 Eres una versión Python de Claude Code con capacidades expandidas.
 Respondes en español por defecto. Eres directo y técnico."""
```

**Verificación:** confirmé que el texto de salida final es idéntico a antes (mismo "Santiago", ahora vía `{DUEÑO}` en vez de hardcodeado). Recompilé todo `01_SRC/` de nuevo (limpio) y corrí `run_claw.py` de punta a punta (exit code 0).
**Seguridad:** sin import circular (verificado); no cambia ningún texto visible, solo la fuente del dato.

---

## Pendiente — decisiones de arquitectura (no de Claude C)

1. `01_SRC/2024-06-19_CLAW_CLAWSPRING_V02.py` importa `claw_personalidad` (no existe) dentro de un `try/except` marcado como "opcional" — puede ser un mecanismo intencional de personalización de usuario. Activar la personalidad "Claw" por defecto es una decisión de producto.
2. `session_memory.py` (usado por `main.py`/`alternative.py`) y el paquete `memory` (usado por `clawspring.py`) son dos sistemas de historial/memoria paralelos con almacenamiento distinto. Cuál debe ser "el oficial", o si deben unificarse, es una decisión de arquitectura.

---

## Archivos incluidos en este parche

- `2024-06-19_CLAW_PYPROJECT_V01.toml` (00_SOPORTE/)
- `2024-06-19_CLAW_REQUIREMENTS_V01.txt` (00_SOPORTE/)
- `2024-06-19_CLAW_ALTERNATIVE_V01.py` (01_SRC/)
- `2024-06-19_CLAW_LAUNCHER_V01.bat` (00_SOPORTE/)
- `2024-06-19_CLAW_PERSONALIDAD_V01.py` (01_SRC/)
- `2024-06-19_CLAW_MAIN_V01.py` (01_SRC/)

Ningún otro archivo del repositorio fue modificado.
