# Informe de Consistencia Documental — CLAW

**Autor:** Claude C (Integrador Documental — misión temporal)
**Fecha:** 2026-07-03
**Alcance de esta misión:** sincronizar y mantener coherente el repositorio documental. No incluye rediseño de arquitectura, desarrollo de SAGE, ni repetición de la auditoría profunda de código.
**Fuente analizada:** `CLAW_FINAL__2_.zip` (contenido local entregado por el Arquitecto).

**Nota de acceso:** no fue posible leer el repositorio directamente desde `github.com/Santiagozuloaga/Cortana` (GitHub bloquea el acceso automatizado a esas páginas). Este informe se basa enteramente en el .zip local, que puede o no coincidir exactamente con el estado actual de `master` en GitHub. Si hay diferencias entre ambos, no las puedo detectar desde aquí.

---

## Resumen ejecutivo

El repositorio tiene una auditoría técnica previa (firmada por Jules, fechada 2024-06-19/2026-06-21) centrada en `01_SRC/` que concluye *"03_DOCS: Bien organizado"*. Mi revisión, centrada específicamente en la capa documental, no confirma esa conclusión: `03_DOCS/` presenta el mismo patrón de duplicación por doble nomenclatura que Jules encontró en el código, y además existe un segundo árbol de documentación casi completo (`CLAW_DOCUMENTACION/`) que la auditoría de Jules no cubrió. También se detectaron documentos "ancla" (README raíz, AGENTS.md) vacíos de contenido, y una colisión de significado sobre el término "SAGE" que aparece con al menos tres sentidos distintos según el documento.

No encontré documentos llamados literalmente "RFC", "Roadmap" o "Constitución" en el .zip entregado. Si existen en otra ubicación (GitHub, otro export), no pude verificarlos — lo señalo como pendiente en la sección 8.

---

## 1. Duplicación por doble convención de nombres (fecha-primero vs. nombre-primero)

**Hallazgo:** casi todo documento de coordinación/instrucciones en `03_DOCS/` existe dos veces: una vez con el nombre "limpio" (p. ej. `INSTRUCCIONES_JULES.md`) y otra con el prefijo de fecha (`2024-06-19_CLAW_INSTRUCCIONES_JULES_V01.md`). Verifiqué por hash MD5 que ningún par es idéntico — el contenido diverge en todos los casos comprobados:

| Documento (par) | Tamaño A | Tamaño B | ¿Hash idéntico? |
|---|---|---|---|
| `INSTRUCCIONES_AIDER.md` / `2024-06-19_..._V01.md` | 3735 | 3847 | No |
| `INSTRUCCIONES_DEVIN.md` / `2024-06-19_..._V01.md` | 3421 | 3525 | No |
| `INSTRUCCIONES_JULES.md` / `2024-06-19_..._V01.md` | 3304 | 3066 | No |
| `INSTRUCCIONES_VSC_AI.md` / `2024-06-19_..._VSCAI_V01.md` | 3688 | 3807 | No (nombres tampoco coinciden: `VSC_AI` vs `VSCAI`) |
| `INSTRUCCIONES_ZENCODER.md` / `2024-06-19_..._V01.md` | 3935 | 3942 | No |
| `README_JULES.md` / `2024-06-19_..._V01.md` | 5325 | 5003 | No |

Esto es consistente con lo que ya reconoce `learnings.txt` del propio repositorio: *"ISO-SAGE naming conflict: formato [AAAA-MM-DD]_[PROYECTO]_[DESCRIPCIÓN]_V[XX] vs incorrecto [PROYECTO]_[AAAA_MM_DD]_. Estandarizar en fecha-primero."* — es decir, el problema ya fue detectado por alguien, pero no se resolvió en la capa documental (solo hay evidencia de que se atacó en `01_SRC/`, ver §7).

**Documento afectado:** todos los pares `INSTRUCCIONES_*` y `README_JULES*` en `03_DOCS/`.

**Impacto:** cualquier persona o agente que abra la versión "limpia" y la versión "V01" recibirá instrucciones distintas sin ninguna señal de cuál es la vigente. Para archivos como `INSTRUCCIONES_JULES.md`, esto significa que Jules podría recibir tareas contradictorias según cuál copia consulte.

**Recomendación:** el Arquitecto (no yo) debe decidir cuál convención es la canónica. Una vez decidida, para cada par: conservar un solo archivo como fuente de verdad y marcar el otro explícitamente como histórico (o eliminarlo), en vez de dejar ambos activos sin distinción. No recomiendo fusionar contenidos automáticamente porque las diferencias no son solo de formato.

---

## 2. Triplicación completa de una subcarpeta dentro de `03_DOCS/`

**Hallazgo (hecho verificado por tamaño de archivo, no por hash completo):** la subcarpeta de documentación "de archivo" existe **tres veces** dentro de `03_DOCS/`, con los mismos 23 archivos y los mismos tamaños en las tres copias:

- `03_DOCS/2024-06-19_CLAW_ARCHIVE_DOCS_V01/`
- `03_DOCS/2024-06-19_CLAW_DOCS_V01/`
- `03_DOCS/CLAW_ARCHIVE_DOCS/`

Incluye `architecture.md`, seis variantes de `README.<idioma>.MD`, `contributor_guide.md`, gifs de demo, logos, y specs bajo `superpowers/`. Un patrón equivalente aparece en `04_ASSETS/` (carpeta `demos/` vs `2024-06-19_CLAW_DEMOS_V02/`, y los mismos logos repetidos con dos nombres distintos).

**Documento afectado:** las tres carpetas de archivo listadas arriba (y, por extensión, `04_ASSETS/`).

**Impacto:** infla el repositorio y, más importante para esta misión, hace ambiguo cuál copia es la que debería tratarse como histórica de solo lectura si alguna llegara a editarse.

**Recomendación:** consolidar en una única carpeta de archivo con nombre estable, y dejar constancia (por ejemplo un solo `README` dentro de esa carpeta) de que es material histórico y no fuente de verdad — tal como pide mi misión, sin necesidad de reescribir el contenido en sí.

---

## 3. Dos árboles de documentación paralelos: `03_DOCS/` vs `CLAW_DOCUMENTACION/`

**Hallazgo:** además de `03_DOCS/` (dentro de la estructura numerada 00–04), existe `CLAW_FINAL/CLAW_DOCUMENTACION/` como carpeta hermana, fuera de esa estructura, con ~40 archivos (incluye subcarpeta `ARCHIVO_NOMENCLATURA/` y varios `.docx`). Parte de su contenido se solapa con `03_DOCS/` y parte es exclusivo de cada lado:

- **Coincide (mismo hash) con la versión "V01" de `03_DOCS`:** `COORDINACION_IAS_COMPLETA.md` = `2024-06-19_CLAW_COORDINACION_IAS_V01.md`.
- **Existe en ambos lados pero con contenido distinto:** las instrucciones para Jules (ver §6).
- **Solo existe en `CLAW_DOCUMENTACION/`:** `ESTADO_ACTUAL_SAGE.md`, `INSTRUCCIONES_SAGE.md`, `SAGE_DELEGACION_BUGS.md`, `TAREA_CASCADE.md`, `TAREA_DEVIN_LOCAL.md`, `ANALISIS_PR_JULES.md`, cinco `.docx` (informes de fase, "Distribución del Equipo de IAs", "Informe Maestro de Ingeniería").
- **Solo existe en `03_DOCS/`:** los ocho `REPORT_*.md` de auditoría técnica y `SUMMARY_EXECUTIVE.md` (ver §7).

**Documento afectado:** la organización general del repositorio documental (`03_DOCS/` y `CLAW_DOCUMENTACION/` como conjunto).

**Impacto:** no hay un único lugar donde buscar "la documentación de CLAW". Un agente o persona que solo mire `03_DOCS/` (la carpeta "oficial" según la estructura P.A.R.A. descrita en `INSTRUCCIONES_JULES.md`) se perderá todo el contenido específico de SAGE, Cascade y Devin que vive únicamente en `CLAW_DOCUMENTACION/`.

**Recomendación:** decidir (el Arquitecto) si `CLAW_DOCUMENTACION/` debe fusionarse dentro de `03_DOCS/`, mantenerse como carpeta separada mientras dure la estabilización, o marcarse como pendiente de migración. Mientras no se decida, sugiero al menos un documento corto en la raíz que explique que ambas carpetas coexisten y cuál consultar para qué — sin fusionar contenido yo mismo, ya que no es una corrección puntual sino una decisión de organización.

---

## 4. El término "SAGE" tiene al menos tres significados distintos en el corpus

**Hallazgo:** revisando el contenido (no solo nombres de archivo), "SAGE" se usa para referirse a cosas distintas según el documento:

1. **Persona/agente coordinador:** en `ESTADO_ACTUAL_SAGE.md` y `COORDINACION_IAS.md`, "Sage" es una configuración de chatbot corriendo sobre OpenClaw (modelo `qwen2.5:0.5b`, personalidad "Jarvis + Ultron + Alfred + Cortana") que coordina y delega bugs a un equipo de herramientas de IA (ChatGPT, VSC AI, Zencoder, Antigravity, Jules, Opal, Codex).
2. **Convención de nomenclatura:** "ISO-SAGE" aparece en `learnings.txt`, `REPORT_REPOSITORY_AUDIT.md` y el script `rename_to_iso_sage.ps1` como el nombre del estándar de nombrado de archivos (`AAAA-MM-DD_CLAW_DESCRIPCIÓN_VXX`).
3. **Producto en desarrollo:** según el encargo que recibí de "el Arquitecto" al inicio de esta misión, SAGE es responsabilidad de "Claude A" como algo que se está construyendo.

Adicionalmente, dos archivos en la raíz del repositorio llevan nombres que sugieren ser documentación de arquitectura de SAGE, pero no lo son:

- `CLAW_FINAL/SAGE` (32 259 bytes)
- `CLAW_FINAL/SAGE OS v4.5 [ARCHITECTURE FROZEN].5 [ARCHITECTURE FROZEN].5 [ARCHITECTURE FROZEN]` (87 395 bytes, nombre con sufijo repetido tres veces — parece un artefacto de guardado duplicado, no un nombre intencional)

Ambos son, en realidad, JSON de metadatos de tema/paleta de una herramienta de presentaciones (`{"metadata":{"visual":{"presentation":{"themes":...`), sin contenido legible sobre arquitectura. El mismo patrón de nombre-con-sufijo-repetido aparece en `CodeBuddy Engineering OS v2.2 (Project CLAW).2 (Project CLAW).2 (Project CLAW)`, también JSON de presentación.

**Documento afectado:** `ESTADO_ACTUAL_SAGE.md`, `COORDINACION_IAS.md`, `learnings.txt`, y los tres archivos raíz de nombre mangled mencionados arriba.

**Impacto:** cualquiera (persona o agente, incluido Claude A) que busque "la documentación de SAGE" puede terminar en un archivo sin relación real con el producto, o confundir el rol coordinador con el producto en desarrollo. Esto es exactamente el tipo de inconsistencia de nombres que mi misión pide detectar.

**Recomendación:** no me corresponde renombrar ni decidir cuál "SAGE" es el correcto (eso toca arquitectura/decisión del Arquitecto o de Claude A). Sí recomiendo que alguien con permiso confirme si los dos archivos raíz con nombre "SAGE..." deben eliminarse o reemplazarse por contenido real, ya que hoy no aportan información y ocupan un nombre muy visible.

---

## 5. Documentos "ancla" sin contenido real

**Hallazgo:** dos documentos que normalmente funcionan como punto de entrada están vacíos de contenido:

- `CLAW_FINAL/README.md` (raíz del repo): contiene únicamente el texto `# TODO`.
- `CLAW_FINAL/AGENTS.md`: contiene únicamente la plantilla sin editar (`<!-- Add custom instructions for the agents below -->`), repetida dos veces dentro del mismo archivo de 114 bytes.

Mientras tanto, `03_DOCS/README.md` (3439 bytes) y `03_DOCS/README_CLAWSPRING.md` (106 498 bytes) sí tienen contenido sustancial.

**Documento afectado:** `README.md` y `AGENTS.md` en la raíz de `CLAW_FINAL/`.

**Impacto:** en GitHub, el `README.md` de la raíz es lo primero que ve cualquier visitante — hoy muestra "TODO". `AGENTS.md` es una convención que varias herramientas de agentes leen automáticamente para instrucciones específicas del repo; al estar vacío, esas herramientas no reciben ninguna instrucción real aunque el archivo exista.

**Recomendación:** esto entra dentro de lo que sí puedo hacer sin rediseñar nada — si el Arquitecto lo autoriza, puedo redactar un `README.md` raíz breve que oriente hacia `03_DOCS/` y `CLAW_DOCUMENTACION/`, y dejar constancia en `AGENTS.md` de qué documento(s) contienen las instrucciones reales para cada agente. No lo hago de oficio porque implica escribir contenido nuevo, no solo señalar inconsistencias.

---

## 6. Contradicciones de contenido entre copias del mismo documento

**Hallazgo A — `COORDINACION_IAS`:** existen tres copias; dos son idénticas por hash (`2024-06-19_CLAW_COORDINACION_IAS_V01.md` en `03_DOCS/` y `COORDINACION_IAS_COMPLETA.md` en `CLAW_DOCUMENTACION/`, ambas con hash `767876c...`), pero la tercera —`03_DOCS/COORDINACION_IAS.md`, la de nombre "más limpio"— tiene hash distinto (`a26b6ff...`) y fecha de modificación más antigua (21-jun) que las otras dos (24-jun y 27-jun). El contenido de esta copia divergente describe un reparto de bugs por especialidad (BUG #1 a ChatGPT, BUG #2 a VSC AI, BUG #7 a Jules, etc.) que no aparece igual en el resto de la documentación revisada.

**Hallazgo B — instrucciones para Jules:** las tres variantes (`INSTRUCCIONES_JULES.md`, su par V01, e `INSTRUCCIONES_JULES_PARA.md` en `CLAW_DOCUMENTACION/`) comparten el mismo encabezado y estructura P.A.R.A. inicial, pero divergen en extensión (402 / 370 / 305 palabras respectivamente) y por tanto en contenido más allá de esa introducción común.

**Documento afectado:** `COORDINACION_IAS.md` (y sus copias), familia `INSTRUCCIONES_JULES*`.

**Impacto:** es imposible saber, solo mirando los nombres de archivo, cuál de las tres versiones de `COORDINACION_IAS` refleja el reparto de trabajo vigente. Para Jules en particular, hay cuatro documentos con instrucciones no idénticas (`INSTRUCCIONES_JULES.md`, su V01, `INSTRUCCIONES_JULES_PARA.md`, y por contenido relacionado `README_JULES.md`/su V01).

**Recomendación:** recomiendo que el Arquitecto (o Jules mismo) confirme cuál copia de cada documento es la vigente. Puedo, si se me pide en una tarea puntual, producir un diff línea por línea de cada par para facilitar esa decisión — no lo incluyo completo aquí porque son varios documentos y el formato de esta misión pide priorizar hallazgos sobre volumen de detalle.

---

## 7. Relación con la auditoría previa (para no repetir trabajo)

Los archivos `SUMMARY_EXECUTIVE.md`, `REPORT_REPOSITORY_AUDIT.md`, `REPORT_DUPLICATES.md`, `REPORT_CLEANUP_PLAN.md`, `REPORT_RECOVERY_PLAN.md`, `REPORT_RISKS.md`, `REPORT_DEPENDENCIES.md` e `REPORT_IMPORT_ANALYSIS.md` (todos en `03_DOCS/`) están firmados por **Jules** y fechados 2024-06-19 / 2026-06-21. Su alcance es `01_SRC/` (imports rotos, carpetas de código espejo, `run_claw.py` roto, cumplimiento ISO-SAGE en nombres de archivo de código). Ese trabajo ya identificó, para el código, el mismo patrón de doble nomenclatura que yo describo en §1 para la documentación — no lo repito ni lo reviso de nuevo.

Donde sí hay una diferencia real: `REPORT_REPOSITORY_AUDIT.md` afirma *"03_DOCS: Bien organizado, contiene la documentación histórica y técnica"*. Mi revisión, enfocada específicamente en documentos, no sostiene esa conclusión (ver §1–§3). No es una contradicción con el trabajo de Jules — su auditoría no tenía como objetivo revisar `03_DOCS/` en profundidad ni conocía, aparentemente, la existencia de `CLAW_DOCUMENTACION/`.

También existe `file_hashes.txt` y `repository_inventory.txt` en la raíz: son inventarios previos, pero cubren únicamente `00_SOPORTE/` y `01_SRC/`, no la documentación. Por eso no encontré ahí trabajo duplicable para esta misión.

---

## 8. Fuera de alcance de esta pasada / pendiente

Por transparencia, esto es lo que **no** revisé a fondo y por qué:

- **Cinco archivos `.docx` en `CLAW_DOCUMENTACION/`** (incluyendo uno de ~2,9 MB) y varios `.docx` de "informe_fase*": no los abrí; mi revisión se apoyó en comparación por hash/tamaño, que no aplica igual a binarios de Word. Si son parte del canon, recomiendo una pasada dedicada.
- **`claude-code-source-code/` y `claw-code/`:** dos árboles de código externo de gran tamaño embebidos en el repositorio, sin un `README` o nota que explique su propósito o relación con CLAW. No revisé su contenido (es código, no documentación, y no es mi función auditarlo), pero su presencia sin documentar es en sí un hallazgo de organización que dejo anotado.
- **`recovery/*.zip`, `RepoBird_PR4_Backup.zip`, `.aider.chat.history.md`, `claw_historial.html`:** parecen respaldos y logs de sesión, no documentación canónica; no los abrí.
- **No encontré archivos llamados "RFC", "Roadmap" o "Constitución"** en este .zip. Si existen con otros nombres o solo en GitHub, no pude verificarlo por el bloqueo de acceso mencionado al inicio.
- **No comparé contra el estado real de `master` en GitHub** por la misma razón de acceso.

---

## Hechos observados vs. inferencias vs. recomendaciones

- **Hechos observados** (verificables directamente: tamaños de archivo, hashes MD5, contenido leído): las duplicaciones y divergencias descritas en §1, §2, §3 y §6; el contenido vacío de §5; el contenido JSON de los archivos "SAGE..." en §4; el alcance de los reportes de Jules en §7.
- **Inferencias** (mi lectura de por qué importa, no un hecho verificado por sí solo): que la copia "de nombre limpio" de `COORDINACION_IAS.md` es la más antigua y por tanto probablemente obsoleta (se infiere de fechas de modificación, no de una marca explícita de "obsoleto" en el archivo); que la confusión sobre "SAGE" puede causar errores prácticos.
- **Recomendaciones**: todas están marcadas como tal en cada sección; ninguna implica que yo haya tomado la decisión — quedan pendientes de aprobación del Arquitecto.

---

## Lo que no hice, por alcance de esta misión

No creé RFCs ni documentos canónicos nuevos. No propuse ni apliqué ninguna reorganización de arquitectura. No toqué ni evalué contenido técnico de SAGE. No modifiqué ni juzgué el trabajo de Jules más allá de delimitar dónde termina su alcance y empieza el mío. No dupliqué el trabajo de auditoría profunda que le corresponde a Claude B.

Quedo a la espera de indicaciones del Arquitecto sobre cuáles de estas recomendaciones autoriza a ejecutar, y de la señal de "Repositorio Congelado" para cerrar esta misión.
